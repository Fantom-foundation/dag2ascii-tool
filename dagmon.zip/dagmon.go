
package main

import (
	"context"
	"fmt"
	"github.com/ethereum/go-ethereum/core/types"
	"math/big"
    "log"

	//"github.com/ethereum/go-ethereum/accounts"
	//"github.com/ethereum/go-ethereum/common"
	//"github.com/ethereum/go-ethereum/core/state"
    //"github.com/ethereum/go-ethereum/core/vm"
    //"github.com/ethereum/go-ethereum/ethdb"
    //"github.com/ethereum/go-ethereum/params"
	//"github.com/ethereum/go-ethereum/rpc"
	"github.com/ethereum/go-ethereum/ethclient"

	//"github.com/Fantom-foundation/go-lachesis/evm_core"
    //"github.com/Fantom-foundation/go-lachesis/hash"
    //"github.com/Fantom-foundation/go-lachesis/inter"
)

func main() {

	fmt.Println("\n\n\n\n====== DAG Monitor 10 ===============================================================")

	node_eth, err := ethclient.Dial("https://mainnet.infura.io")
	if err != nil { log.Fatal(err) } else { fmt.Println("Connected to mainnet.infura.io") }

	Node1, err := ethclient.Dial("http://18.189.195.64:4001" )
	if err != nil { log.Fatal(err) } else { fmt.Println("Connected to lachesis Node1") }

	Node2, err := ethclient.Dial("http://18.191.96.173:4002" )
	if err != nil { log.Fatal(err) } else { fmt.Println("Connected to lachesis Node2") }

	Node3, err := ethclient.Dial("http://18.222.120.223:4003")
	if err != nil { log.Fatal(err) } else { fmt.Println("Connected to lachesis Node3") }

	blk := new(types.Block)

	fmt.Println("\n=== Get Block by number ===\n")
	BNum := big.NewInt(1)

    //===========================================================
	blk, err = node_eth.BlockByNumber(context.Background(), BNum)
	fmt.Printf("Node Ethereum block %d:",BNum)
	fmt.Println(blk)
	//--------------
	blk, err = Node1.BlockByNumber(context.Background(), BNum)
	fmt.Printf("Node1 block %d:",BNum)
	fmt.Println(blk)
	//--------------
	blk, err = Node2.BlockByNumber(context.Background(), BNum)
	fmt.Printf("Node2 block %d:",BNum)
	fmt.Println(blk)
	//--------------
	blk, err = Node3.BlockByNumber(context.Background(), BNum)
	fmt.Printf("Node3 block %d:",BNum)
	fmt.Println(blk)
	//===========================================================



	//fmt.Println("Extract Header")
	//h := blk.Header()
	//fmt.Println(h)

	fmt.Println("=====================================================================")
}
